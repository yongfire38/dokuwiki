INSERT INTO OE2TNUSERINFO VALUES('admin','admin','','','21232f297a57a5a743894a0e4a801fc3','01');

INSERT INTO OE2TNIDS VALUES('MNTRGSERVERINFO',0);
INSERT INTO OE2TNIDS VALUES('OE2SYSHTTP',0);
INSERT INTO OE2TNIDS VALUES('OE2SYSSOCKET',0);
INSERT INTO OE2TNIDS VALUES('OE2TNMBCLIENT',0);
INSERT INTO OE2TNIDS VALUES('SAMPLE',0);
INSERT INTO OE2TNIDS VALUES('OE2SYSFILESYSTEM',0);
INSERT INTO OE2TNIDS VALUES('OE2TNCNTNRINFO',0);
INSERT INTO OE2TNIDS VALUES('OE2SYSDB',0);
INSERT INTO OE2TNIDS VALUES('OE2SYSPROCESS',0);
INSERT INTO OE2TNIDS VALUES('OE2SYSNETWORK',0);

insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2019', '모니터링사용자역할', '모니터링사용자역할', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('COM046', '실행상태구분', '실행상태구분', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('COM047', '실행주기구분', '실행주기구분', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('COM048', 'DBMS종류', 'DBMS종류', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2001', '모니터링여부', '모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2002', '서버종류', '서버종류', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2003', '모델모니터링여부', '모델모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2004', '스케쥴모니터링여부', '스케쥴모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2005', 'OS모니터링여부', 'OS모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2006', '메모리모니터링여부', '메모리모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2007', '클래스모니터링여부', '클래스모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2008', '스레드모니터링여부', '스레드모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2009', 'JDBC풀모니터링여부', 'JDBC풀모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2010', '세션모니터링여부', '세션모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2011', 'DBMS종류', 'DBMS종류', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2012', '웹서비스종류', '웹서비스종류', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2013', '프로세스상태', '프로세스상태', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2014', '웹서비스상태', '웹서비스상태', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2015', '호출관계분석여부', '호출관계분석여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2016', '오류사항모니터링여부', '오류사항모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2017', 'JDBC모니터링여부', 'JDBC모니터링여부', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
insert into OE2TCCMMNCODE (CODE_ID, CODE_ID_NM, CODE_ID_DC, CL_CODE, USE_AT, FRST_REGISTER_PNTTM, FRST_REGISTER_ID, LAST_UPDUSR_PNTTM, LAST_UPDUSR_ID)
values ('OE2018', '스케쥴상태', '스케쥴상태', 'EFC', 'Y', NOW(), 'SYSTEM', NOW(), 'SYSTEM');
commit;
prompt 22 records loaded
prompt Loading OE2TCCMMNDETAILCODE...
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('COM048', '01', 'Oracle', 'Oracle', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('COM048', '02', 'Mysql', 'Mysql', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('COM048', '03', 'Tibero', 'Tibero', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('COM048', '04', 'Altibase', 'Altibase', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('COM046', '01', '정상', '정상', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('COM046', '02', '비정상', '비정상', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2019', '01', '모니터링관리자', '모니터링관리자', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2019', '02', '모니터링사용자', '모니터링사용자', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '412', 'Precondition Failed ', 'Precondition Failed ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '413', 'Request Entity Too Large ', 'Request Entity Too Large ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '414', 'Request URI Too Long ', 'Request URI Too Long ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '415', 'Unsupported Media Type ', 'Unsupported Media Type ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '416', 'Requested Range Not Satisfiable ', 'Requested Range Not Satisfiable ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '417', 'Expectation Failed ', 'Expectation Failed ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '500', 'Internal Server Error ', 'Internal Server Error ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '501', 'Not Implemented ', 'Not Implemented ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '502', 'Bad Gateway ', 'Bad Gateway ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '503', 'Service Unavailable ', 'Service Unavailable ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '504', 'Gateway Timeout ', 'Gateway Timeout ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '505', 'HTTP Version Not Supported ', 'HTTP Version Not Supported ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2015', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2015', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2016', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2016', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2017', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2017', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2018', 'B', 'STATE_BLOCKED', 'STATE_BLOCKED', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2018', 'P', 'STATE_PAUSED', 'STATE_PAUSED', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2018', 'C', 'STATE_COMPLETE', 'STATE_COMPLETE', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2018', 'E', 'STATE_ERROR', 'STATE_ERROR', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2018', 'N', 'STATE_NORMAL', 'STATE_NORMAL', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2001', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2001', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2002', 'JB', 'Jboss', 'Jboss', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2002', 'JE', 'Jeus', 'Jeus', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2002', 'TC', 'Tomcat', 'Tomcat', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2002', 'WL', 'WebLogic', 'WebLogic', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2003', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2003', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2004', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2004', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2005', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2005', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2006', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2006', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2007', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2007', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2008', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2008', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2009', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2009', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2010', 'Y', '예', '예', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2010', 'N', '아니오', '아니오', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2011', '01', 'Oracle', 'Oracle', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2011', '02', 'Mysql', 'Mysql', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2011', '03', 'Tibero', 'Tibero', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2011', '04', 'Altibase', 'Altibase', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2012', '001', 'JBoss', 'JBoss', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2012', '002', 'Jeus', 'Jeus', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2012', '003', 'Tomcat', 'Tomcat', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2012', '004', 'WebLogic', 'WebLogic', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2013', '100', 'Runnable', 'Runnable', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2013', '200', 'Sleeping', 'Sleeping', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2013', '300', 'Swapped', 'Swapped', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2013', '400', 'Zombie', 'Zombie', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2013', '500', 'Stopped', 'Stopped', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '100', 'Continue ', 'Continue ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '101', 'Switching Protocols ', 'Switching Protocols ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '200', 'OK ', 'OK ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '201', 'Created ', 'Created ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '202', 'Accepted ', 'Accepted ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '203', 'Non-Authoritative Information ', 'Non-Authoritative Information ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '204', 'No Content ', 'No Content ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '205', 'Reset Content ', 'Reset Content ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '206', 'Partial Content ', 'Partial Content ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '300', 'Multiple Choices ', 'Multiple Choices ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '301', 'Moved Permanently ', 'Moved Permanently ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '302', 'Found ', 'Found ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '303', 'See Other ', 'See Other ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '304', 'Not Modified ', 'Not Modified ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '305', 'Use Proxy ', 'Use Proxy ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '307', 'Temporary Redirect ', 'Temporary Redirect ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '400', 'Bad Request ', 'Bad Request ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '401', 'Unauthorized ', 'Unauthorized ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '403', 'Forbidden ', 'Forbidden ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '404', 'Not Found ', 'Not Found ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '405', 'Method Not Allowed ', 'Method Not Allowed ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '406', 'Not Acceptable ', 'Not Acceptable ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '407', 'Proxy Authentication Required ', 'Proxy Authentication Required ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '408', 'Request Timeout ', 'Request Timeout ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '409', 'Conflict ', 'Conflict ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '410', 'Gone ', 'Gone ', 'Y');
insert into OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT)
values ('OE2014', '411', 'Length Required ', 'Length Required ', 'Y');
INSERT INTO OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT) VALUES('OE2020', '000', 'N/A', 'N/A', 'Y');
INSERT INTO OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT) VALUES('OE2020', '001', 'Windows 98', 'Windows 98', 'Y');
INSERT INTO OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT) VALUES('OE2020', '002', 'Windows server', 'Windows Server', 'Y');
INSERT INTO OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT) VALUES('OE2020', '003', 'Windows NT 5.0', 'Windows 2000', 'Y');
INSERT INTO OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT) VALUES('OE2020', '004', 'Windows NT 5.1', 'Windows XP', 'Y');
INSERT INTO OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT) VALUES('OE2020', '005', 'Windows NT 5.2', 'Windows Server 2003', 'Y');
INSERT INTO OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT) VALUES('OE2020', '006', 'Windows NT 6.0', 'Windows Vista/Server 2008', 'Y');
INSERT INTO OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT) VALUES('OE2020', '007', 'Windows NT 6.1', 'Windows 7', 'Y');
INSERT INTO OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT) VALUES('OE2020', '008', 'Mac OS X', 'Mac OS X', 'Y');
INSERT INTO OE2TCCMMNDETAILCODE (CODE_ID, CODE, CODE_NM, CODE_DC, USE_AT) VALUES('OE2020', '009', 'Linux', 'Linux', 'Y');

COMMIT;