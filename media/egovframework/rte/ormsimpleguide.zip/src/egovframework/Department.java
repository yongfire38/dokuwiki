package egovframework;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Department implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	private String deptId;
	
	private String deptName;
	
    private Date createDate;
    
	private BigDecimal empCount;
	
	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}	
	
	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}	
	
	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	
	public BigDecimal getEmpCount() {
		return empCount;
	}
	
	public void setEmpCount(BigDecimal empCount) {
		this.empCount = empCount;
	}	

}
