package egovframework.com.utl.sys.srm.service;

public interface EgovServerResrceMntrngMBean {
	public double getCpuUsage();
	
	public double getMemoryUsage(); 
}
