/*
 * Copyright 2008-2009 MOPAS(Ministry of Public Administration and Security).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.rte.fdl.idgnr;

/**
 * @Class Name : EgovIdGnrStrategy.java
 * @Description : Id Generation 정책 Interface 클래스
 * @Modification Information
 * @
 * @  수정일     수정자               수정내용
 * @ -------    --------    ---------------------------
 * @ 2009.02.01 김태호      최초 생성
 *
 *  @author Taeho Kim
 *  @since 2009. 02. 01
 *  @version 1.0
 *  
 *  Copyright (C) 2009 by MOPAS  All right reserved.
 */
public interface EgovIdGnrStrategy {
	/**
	 * 정책을 담은 아이디 생성하여 결과 리턴
	 * 
	 * @param originalId
	 *            original id to be converted
	 * @return assembled id
	 */
	String makeId(String originalId);
}
