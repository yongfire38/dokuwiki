/*
 * Copyright 2008-2009 MOPAS(Ministry of Public Administration and Security).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.rte.fdl.crypto;

import egovframework.rte.fdl.crypto.exception.UnsupportedException;
import java.math.BigDecimal;
/**
 * @Class Name : EgovEDcryptionService.java
 * @Description : 암복화 Interface Class
 * @Modification Information  
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2009.03.10    김종호        최초생성
 * 
 * @author 개발프레임웍크 실행환경 개발팀 김종호
 * @since 2009. 03.10
 * @version 1.0
 * @see
 * 
 *  Copyright (C) by MOPAS All right reserved.
 */
public interface EgovEDcryptionService {
	
	public byte[] encrypt();
	 
    public byte[] decrypt();
    
    public BigDecimal encrypt(BigDecimal bigdecimal);
    
    public BigDecimal decrypt(BigDecimal bigdecimal);
    
    public byte[] Aria_encrypt(BigDecimal bigdecimal);
    
    public BigDecimal Aria_decrypt(byte[] endecimal);
  
    public void setComformStr(String pwd) throws UnsupportedException;
 
    public void getComformStr(String pwd)throws UnsupportedException;
    
    public void setAlgorithm(String alg)throws UnsupportedException;
    
    public void setConfig(int is_which,String str_or_file)throws UnsupportedException;
    
    public void setPlainDigest(boolean isplan)throws UnsupportedException;
      
	public boolean checkPassword(String planPD,byte[] cryptoPD);
	
	public void setARIAConfig(int is_which,byte[] p_arr)throws UnsupportedException;
	
}
