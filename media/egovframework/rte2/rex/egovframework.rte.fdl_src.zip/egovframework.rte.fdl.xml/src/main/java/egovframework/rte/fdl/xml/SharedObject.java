/*
 * Copyright 2008-2009 MOPAS(Ministry of Public Administration and Security).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.rte.fdl.xml;

import java.io.Serializable;
/**
 * @Class Name : SharedObject.java
 * @Description : Object Wrap 구조체 Class
 * @Modification Information  
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2009.03.18    김종호        최초생성
 * 
 * @author 개발프레임웍크 실행환경 개발팀 김종호
 * @since 2009. 03.18
 * @version 1.0
 * @see
 * 
 *  Copyright (C) by MOPAS All right reserved.
 */
public class SharedObject implements Serializable {
   /** Object 조회 Key **/
   String key = null;
   /** 저장 Object **/
   Object value = null;
   /**
    * SharedObject 생성자
    * @param key - Object key
    * @param value - 저장 object
    * @see 개발프레임웍크 실행환경 개발팀
    */
   public SharedObject(String key,Object value)
   {
	   this.key = key;
	   this.value = value;
   }
   /**
    * 키 리턴
    * @return 키 
    * @see 개발프레임웍크 실행환경 개발팀
    */
   public String getKey()
   {
	   return key;
   }
   /**
    * Object 리턴
    * @return Object
    * @see 개발프레임웍크 실행환경 개발팀
    */
   public Object getValue()
   {
	   return value;
   }
}
