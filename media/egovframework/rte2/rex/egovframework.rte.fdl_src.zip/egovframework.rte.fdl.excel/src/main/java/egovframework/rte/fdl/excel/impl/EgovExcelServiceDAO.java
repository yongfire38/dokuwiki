/*
 * Copyright 2008-2009 MOPAS(Ministry of Public Administration and Security).
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.rte.fdl.excel.impl;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ibatis.SqlMapClientCallback;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.ibatis.sqlmap.client.SqlMapExecutor;


/**
 * 
 * @author sjyoon
 *
 */
//@Repository("egovExcelServiceDAO")
public class EgovExcelServiceDAO extends SqlMapClientDaoSupport {

	protected Log log = LogFactory.getLog(this.getClass());
	private SqlMapClient sqlMapClient= null;

	public EgovExcelServiceDAO(SqlMapClient sqlMapClient) {
		this.sqlMapClient = sqlMapClient;
		super.setSqlMapClient(sqlMapClient);
	}

	/**
	 * 엑셀서비스의 배치업로드를 실행한다.
	 * @param queryId
	 * @param list
	 * @return
	 */
	public Integer batchInsert(final String queryId, final List<Object> list) {
        return (Integer) getSqlMapClientTemplate().execute(
            new SqlMapClientCallback() {

                public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {

                    executor.startBatch();
                    
                    for (Iterator<Object> itr = list.iterator(); itr.hasNext();) {
                        executor.insert(queryId, itr.next());
                    }

                    return executor.executeBatch();
                }
            });
    }
	
	/**
	 * 엑셀서비스의 배치업로드를 실행한다.
	 * 업로드할 엑셀의 시작 위치를 정하여 지정한 셀부터 업로드한다. 
	 * @param queryId
	 * @param list
	 * @param start
	 * @return
	 */
	public Integer batchInsert(final String queryId, final List<Object> list, final int start) {
        return (Integer) getSqlMapClientTemplate().execute(
            new SqlMapClientCallback() {

                public Object doInSqlMapClient(SqlMapExecutor executor) throws SQLException {
                    
                    executor.startBatch();
                    
                    for (int i = start; i < list.size(); i++) {
                    	executor.insert(queryId, list.get(i));
                    }

                    return executor.executeBatch();
                }
            });
    }

}
