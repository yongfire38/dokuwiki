package egovframework.rex.util.fileupload.single.service;

/**
 * @file Name : MultiPartFileUploadBean.java
 * @Description : MultiPartFileUploadBean class
 * @Modification Information
 * @
 * @  수정일         수정자                   수정내용
 * @ -------    --------    ---------------------------
 * @ 2009.03.05      이동도          최초 생성
 *
 *  @author 실행환경 개발팀 이동도
 *  @since 2009.03.05
 *  @version 1.0
 *  @see
 *  
 *  Copyright (C) 2009 by MOPAS  All right reserved.
 */

import org.springframework.web.multipart.MultipartFile;

public class MultiPartFileUploadBean {
    
    private String        type;
    
    private MultipartFile file;
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
    public void setFile(MultipartFile file) {
        this.file = file;
    }
    
    public MultipartFile getFile() {
        return file;
    }
    
}