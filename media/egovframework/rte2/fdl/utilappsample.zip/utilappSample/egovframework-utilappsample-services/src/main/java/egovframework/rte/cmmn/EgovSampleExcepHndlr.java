package egovframework.rte.cmmn;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import egovframework.rte.fdl.cmmn.exception.handler.ExceptionHandler;



public class EgovSampleExcepHndlr implements ExceptionHandler {

    protected Log log = LogFactory.getLog(this.getClass());
    
    /*
    @Resource(name = "otherSSLMailSender")
    private SimpleSSLMail mailSender;
	*/
    
    public void occur(Exception ex, String packageName) {

	log.debug(" EgovServiceExceptionHandler run...............");
	try {
	    //mailSender. send(ex, packageName);
	    log.debug(" sending a alert mail  is completed ");
	} catch (Exception e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	

    }

}
